# Errata

Due to notation mismatches, some of the formulae were printed erroneously in the book  
Here are the page wise correction.

OLD implies old erroneous text that is in the print  
NEW implies the corresponding correction

<img src="https://user-images.githubusercontent.com/3656100/147462604-1ce197f7-61f6-487e-8b97-68b63a2bcd84.png" width="800px"/>
<img src="https://i.imgur.com/LNI7Z82.png" width="800px"></img>
<img src="https://i.imgur.com/Ptf8B08.png" width="800px"></img>
<img src="https://i.imgur.com/FNJxzVl.png" width="800px"></img>
