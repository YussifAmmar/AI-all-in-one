# Chapter 1
Answer to the 6th quesiton of has wrong formula

![image](https://user-images.githubusercontent.com/3656100/167239418-1e4d1a53-c389-4e65-9e07-0a3696f1ddc3.png)

The correct answer should be   
![image](https://user-images.githubusercontent.com/3656100/167239493-493ffa43-2c2f-4b86-b799-0c16816b7d44.png)
