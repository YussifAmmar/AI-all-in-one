# Moving a model to production

There are two sections in this chapter which are explained as video walkthroughs below

### 1. Creating a FastAPI Application and Creating a Docker Container out of it
[https://www.youtube.com/watch?v=4ylSSIwinSI](https://www.youtube.com/watch?v=4ylSSIwinSI)

### 2. Moving and Deploying the Container in Production
[https://www.youtube.com/watch?v=xpaod-htkFo](https://www.youtube.com/watch?v=xpaod-htkFo)
